"""
Minimal Color MTP color analyzer
Part of MCM
Created the 2024/06/21 12:00
v0
v0.1 att deal with usb side
v0.2 deal wiht mirror effect
@author: Nicolas Hardy

Think to hue color mode in addtion of RGB
img_hsv = skim.color.convert_colorspace(img, 'RGB', 'HSV')

"""
__version__ = 0.2

import skimage as skim
from pathlib import Path
import csv
import datetime
import pandas as pd
import numpy as np

"""Functions / Classes here"""


def autonamewells(dataplate, listoflabelsx, listoflabelsy):
    """Function to identify well from position and set coordinates A1, A2,... H11, H12
    """
    assert "centroid-1" in dataplate.columns, "Need dataframe from regionprops_table with centroid properties"
    assert "centroid-0" in dataplate.columns, "Need dataframe from regionprops_table with centroid properties"
    dataplate = dataplate.assign(col = pd.qcut(dataplate["centroid-1"],q=len(listoflabelsx),labels=listoflabelsx).astype("str"))
    dataplate = dataplate.assign(row = pd.qcut(dataplate["centroid-0"],q=len(listoflabelsy),labels=listoflabelsy).astype("str"))
    dataplatecoord = dataplate.assign(well = dataplate["row"]+dataplate["col"]).sort_values(by=["well"])
    return dataplatecoord

def reccorddate(plate, csvfile, listdataname):
    """Function to save data as csv file
    provide dataframe and path of csv file
    create one if no exist else add data
    """
    dictdata = plate[listdataname].to_dict(orient="records") # list of dict reccords with key as column and value as value
    try:
        if not csvfile.is_file():
            with open(csvfile, 'w', newline='') as csvfileopen:
                writer = csv.DictWriter(csvfileopen, fieldnames=listdataname)
                writer.writeheader()
                for data in dictdata:
                    writer.writerow(data)
        else:
            with open(csvfile, 'a', newline='') as csvfileopen:
                writer = csv.DictWriter(csvfileopen, fieldnames=listdataname)
                for data in dictdata:
                    writer.writerow(data)
    except IOError:
        print("I/O error")

def readimage(pathmask, pathimg, datetimetag, pathcsv, alpha, beta, usbatright):
    """Function to read image and extract RGB
    compute G/B and set pH with correlation
    (G_B) = alpha*pH + beta <=> pH = ((G_B)-beta)/alpha
    """
    img = skim.io.imread(pathimg) # load new file
    msk = skim.io.imread(pathmask) # load mask file
    #Std image 
    img = np.flipud(img) # flipup-down comp scanner mirror effect
    #deal with usb port
    if usbatright:
        img = skim.transform.rotate(img,-90,resize=True)
    else:
        img = skim.transform.rotate(img,+90,resize=True)
    img = skim.transform.resize(img, msk.shape) # force the same shape between image and mask
    props = skim.measure.regionprops_table(msk, img, properties=('label','intensity_mean',"centroid","image_intensity"))
    data = pd.DataFrame(props) # conversion to DataFrame
    data.rename(columns={"intensity_mean-0" : "R", "intensity_mean-1" : "G", "intensity_mean-2": "B"}, inplace=True) # rename
    #compute G_B
    data["G_B"] = data.G/data.B

    #compute pH
    data["pH"] = data["G_B"].add(-beta).div(alpha)
    #named wells
    longeury, largeurx = msk.shape  # (y, x)
    listofcolumnlabels = ["01","02","03","04","05","06","07","08","09","10","11","12"]
    listofrowlabels = ["A","B","C","D","E","F","G","H"]
    plates=[]
    
    #select a plate 1
    plate1 = data.loc[(data["centroid-0"]<longeury/2)].loc[data["centroid-1"]<largeurx/2] # 0 = axeY and 1 = axeX
    plate1 = autonamewells(plate1.assign(plate=1).assign(datetime=datetimetag), listofcolumnlabels, listofrowlabels)

    #select a plate 2 ==> plate 2
    plate2 = data.loc[(data["centroid-0"]<longeury/2)].loc[data["centroid-1"]>largeurx/2] # 0 = axeY and 1 = axeX
    plate2 = autonamewells(plate2.assign(plate=2).assign(datetime=datetimetag), listofcolumnlabels, listofrowlabels)

    #select a plate 3  ==> plate3
    plate3 = data.loc[(data["centroid-0"]>longeury/2)].loc[data["centroid-1"]<largeurx/2] # 0 = axeY and 1 = axeX
    plate3 = autonamewells(plate3.assign(plate=3).assign(datetime=datetimetag), listofcolumnlabels, listofrowlabels)

    #select a plate 4 ==> plate 1
    plate4 = data.loc[(data["centroid-0"]>longeury/2)].loc[data["centroid-1"]>largeurx/2] # 0 = axeY and 1 = axeX
    plate4 = autonamewells(plate4.assign(plate=4).assign(datetime=datetimetag), listofcolumnlabels, listofrowlabels)

    plates.append(plate1)
    plates.append(plate2)
    plates.append(plate3)
    plates.append(plate4)
    
    for plate in plates:
        reccorddate(plate, pathcsv, ["datetime","plate","well","R","G","B","G_B","pH"])
    return True


if __name__ == "__main__":
    """here argparser code"""
    """code here"""
    readimage(pathmask,pathimg,datetimetag,pathcsv,alpha,beta)
