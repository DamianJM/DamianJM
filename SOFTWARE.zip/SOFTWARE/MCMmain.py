"""
Minimal Color MTP MCM
Created the 2024/06/20 17h00
v0.0 first creactiob
v0.1 Use plumbum instead of subprocess shoort code
v0.2 add calibration and change args
v0.3 add deal with images
v0.5 add plot during run
v0.6 update plot and add excel export and folder decicate to trial
v0.7 add option to keep last image
v0.8 change in class Handlerimagefile + option for usb port side (only arg)
v0.9 stop program avec saving conf

This file is part of MCM-Picoly.

    MCM-Picoly is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    MCM-Picoly is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with MCM-Picoly.  If not, see <https://www.gnu.org/licenses/>.

@author: Nicolas Hardy
"""
import subprocess
import datetime
from pathlib import Path
import argparse
import os
import time
import sys
import pickle
import plumbum
import re
import MCMcolor
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import pandas as pd
import plotly.express as px

__version__ = 0.9

"""Functions / Classes here"""
def open_folder(path):
    """Open the folder 'path/to/your/folder' with the system's file explorer
    only at the end of the run
    """
    if sys.platform == "win32":
        os.startfile(path)
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])

def numplate(scanner,folder,logfile,outputfolder):
    """Function to scanne MTP
    """
    scanningtime  = datetime.datetime.now()
    datetimestamp = scanningtime.strftime("%Y%m%d%H%M")
    if not outputfolder.exists():
        Path.mkdir(outputfolder)
    outputfile = outputfolder.joinpath(f"{datetimestamp}MTP.tiff")
    # log scan order
    logfileobj = open(logfile, 'a')
    logfileobj.write(f"{scanningtime.strftime('%Y-%m-%d %H:%M:%S')} file {outputfile}\n")
    logfileobj.close()
    print(f"Scanning time at {datetime.datetime.now().time().strftime('%H:%M:%S')}:\n {datetimestamp}:{outputfile}")
    numimage = scanimage["-d"][f'{scanner}']["--format=tiff"]["--output-file"][f'{outputfile}']["--progress"][f"--resolution"]["600"]["--mode"]["Color"]
    #print(numimage)
    #try:
    numimage & plumbum.FG
    #except Exception as err:
    #    print(f"\a\nError:\nUnable to scan images\n{err}") #sound + error message
    #else:
    print(f"scanning done for {outputfile}")
    return scanningtime

def extractqoted(text,quotestringf, quotingstrinb):
    """Function print element(s) quoted in a string "text"
    used for scanimage -L cmd
    """
    listofquoted = re.findall(rf"{quotestringf}([^{quotingstrinb}]*)'",text)
    for element in listofquoted:
        print(element)
    return listofquoted

def plotallMTP(pathcsv,folder,endofrun,valueofinterest="pH"):
    """Function to write html plot
    """
    colorpHdata = pd.read_csv(pathcsv,parse_dates=["datetime"])
    for plate in colorpHdata.plate.unique():
        colorpHdataplate = colorpHdata.loc[lambda df : df["plate"]==plate]
        formatedata = colorpHdataplate.pivot(index="datetime", columns="well", values=valueofinterest)
        formatedata.set_index(formatedata.index-formatedata.index[0], inplace=True) # compute deltatime from begining of fermentation
        formatedata.set_index(formatedata.index.total_seconds()/3600, inplace=True) # convert index in decimal of hours
        fig = px.line(formatedata,
                x=formatedata.index,
                y=formatedata.columns,
                title=f"Color follow-up of plate {plate}",
                template="simple_white").update_layout(yaxis_title=f"{valueofinterest}",
                                                        xaxis_title=f"Time",
                                                        yaxis_range=[3.5,8],
                                                        modebar_add=["v1hovermode", "toggleSpikeLines"]
                                                        ) 
        fig.write_html(folder.joinpath(f"MTP{plate}_{valueofinterest}.html"))
        if endofrun:
            formatedata.to_excel(folder.joinpath(f"MTP{plate}_{valueofinterest}.xlsx"))
    return True

class Handlerimagefile(FileSystemEventHandler):

    def __init__(self): #notre méthode de construction
        self.keepimage = keepimage

    def on_created(self, event): # when file is created
        global pathmask
        global pathcsv
        global alpha
        global beta
        global datetimetag
        global keepimage
        global endofrun
        global folderout
        global usbatright
        self.keepimage = keepimage
        # do something, eg. call your function to process the image
        pathfile = Path(event.src_path) # conversion to Path object
        # do something, eg. call your function to process the image
        pathfile = Path(event.src_path) # conversion to Path object
        print(f"A new file is detected: {pathfile.name} at {datetime.datetime.now().time().strftime('%H:%M:%S')}")
        if pathfile.suffix == ".tiff":
            time.sleep(5) # wait starting of scanner 5s buffer time
            #Wait end of file creation by scooting file size stabilization
            historicalSize = -1
            while (historicalSize != pathfile.stat().st_size): # do nothing until file stop to grow
                historicalSize = pathfile.stat().st_size
                time.sleep(3)
            print(f"Start processing new file {pathfile.name} at {datetime.datetime.now().time().strftime('%H:%M:%S')}")
            try:
                MCMcolor.readimage(pathmask, pathfile, datetimetag, pathcsv, alpha, beta, usbatright)
            except Exception as err:
                print(f"Issue with image: {pathfile}\n{err}")
                pass
            try:
                plotallMTP(pathcsv,folderout,endofrun)
            except Exception as err:
                print(f"Issue with csv file: {pathcsv}\n{err}")
            print(f"End of conversion of file: {pathfile.name} at {datetime.datetime.now().time().strftime('%H:%M:%S')}")
            if not self.keepimage:
                Path.unlink(pathfile)
                print(f"File {pathfile.name} deleted\n--------------")


if __name__ == "__main__":
    """here argparser code"""
    parser = argparse.ArgumentParser(prog="Minimal Color of Microplate", description = "CLI program to record color of MTPs help to a flatbed scanner", epilog="Need 'mask.tiff' file on working directory created by MCM_mask_creator.ipynb\nDevelopped by Nicolas HARDY")
    parser.add_argument("trialtime", metavar = "timexp", type = float, help = "Acquisition time in hours")
    parser.add_argument('-r', '--rate', type = float, default=2, help = "Frequence/rate of aquisition in minutes default value 2 minutes")
    parser.add_argument('-f', '--folder', type = str, default=Path(os.path.realpath(__file__)).parents[0], help = "Set a specific working directory")
    parser.add_argument('-ss', '--searchscan', action=argparse.BooleanOptionalAction, help = "Search available devices")
    parser.add_argument('-sn', '--scanner', type = str, default=None, help = "Set a scanner")
    parser.add_argument('-s', '--saveconf', action="store_true", help = "Save current configuration in working directeory")
    parser.add_argument('-c', '--pHcalibration', nargs=2, metavar=("alpha", "beta"),type = float, help='pH = ((G_B)-beta)/alpha <=> (G_B) = alpha*pH + beta')
    parser.add_argument('-k', '--keepimage', action="store_true", help = "Keep images with this option", default=False)
    parser.add_argument('-kl', '--keeplastimage', action="store_true", help = "Keep images last with this option") # "store_false" or "store_true"
    group = parser.add_mutually_exclusive_group()
    group.add_argument('-g','--usbleft', action='store_true', help ="Use it if you put the USB port at left")
    group.add_argument('-d','--usbright', action='store_true',help ="Use it if you put the USB port at right")

    # parse args
    args = parser.parse_args()
    # load args
    trialtime = args.trialtime #deal with run time
    rate = args.rate # deal with scanning rate
    folder = Path(args.folder) # deal with folder
    folderout = folder.joinpath(f"MCM{datetime.datetime.now().strftime('%Y%m%d')}") #set folder as new one #####
    folderout.mkdir(exist_ok=True) # crear outputfolder if doest not exist 
    outputfolder = folder.joinpath("IMG") # image saving folder
    paramfile = folder.joinpath("MCMparam") # file to store MCM parameters
    scanfile = folder.joinpath("SCANparam") # file to store scanner name
    logfile = folder.joinpath(f"log{datetime.datetime.now().strftime('%Y%m%d')}.txt") # path of log file (Q&D)
    outputfolder.mkdir(exist_ok=True) # crear outputfolder if doest not exist 
    keepimage = args.keepimage # keep image
    keeplastimage = args.keeplastimage # keep last image
    endofrun = False
    #search scanner if -ss/--searchscan option
    if args.searchscan:
        scanimage = plumbum.local["scanimage"]  #creat scanimage handler
        cmsearchscan = scanimage["-L"]
        text = cmsearchscan() # store terminal output in text
        listofscan = extractqoted(text,"`","'") # extract element (scanner name) between "'"
        pickle.dump(listofscan, open(scanfile, 'wb')) # save scanner names
        exit()
    
    # deal with configuration
    if args.saveconf:
        print(f"Save configuration")
        #deal with USB side
        if args.usbleft:
            usbatright = False
        elif args.usbright:
            usbatright = True
        else:
            print("To save conf you must set USB side\nPlease specify usb port side with -g/--usbleft or -d/--usbright")
            exit()
        if args.pHcalibration:
            alpha, beta = args.pHcalibration # unpack alpha and beta for calib
            if args.scanner:
                conf = [args.scanner, alpha, beta,usbatright]
                pickle.dump(conf, open(paramfile, 'wb'))
                print(f"configuration saved{conf}")
                exit()
            else:
                print("To save conf you must use --scanner/-sn also")
                exit()
        else:
            print("To save conf you must use --pHcalibration/-c")
            exit()
    # load configuration
    if paramfile.is_file():
        conf = pickle.load(open(paramfile, 'rb')) # read conf file
        scanner, alpha, beta, usbatright = conf # load conf
        if args.scanner:
            scanner = args.scanner
        if args.pHcalibration:
            alpha, beta = args.pHcalibration
        if args.usbleft:
            usbatright = False
        elif args.usbright:
            usbatright = True

    else:
        print("First create conf file with -s/--saveconf")
        exit()
    
    """code here"""
    # set run duration
    runduration = datetime.timedelta(hours = trialtime) # time before stopping the run
    startime = datetime.datetime.now()
    endtime = startime+runduration
    
    #parameter for AIM
    pathmask = folder.joinpath("mask.tiff")
    pathcsv = folderout.joinpath("data.csv")
    #datetimetag = datetime.datetime.now() # for debug to comment for production
    
    #Print run' setings
    print(f"\
    The working directory: {folder}\n\
    data directory {folderout}\n\
    The run will stop after {trialtime} hours\n\
    i.e. {endtime.strftime('%Y-%m-%d %H:%M:%S')}\n\
    One point every {rate} minutes\
    Device used: {scanner}\n\
    (G_B) = {alpha}*pH + {beta}\n\
    Mask: {pathmask}\n\
    pathcsv: {pathcsv}\n\
    The scanner's USB port is at {['rigth [||]--UBS--PC'if usbatright else 'left PC--USB--[||]']} \n\
    ")
    
    # watchdog to do work when file created
    
    observer = Observer()
    event_handler = Handlerimagefile() # create event handler
    observer.schedule(event_handler, path=outputfolder)
    observer.start()
    
    #Check if Sane and scanimage
    scanimage = plumbum.local["scanimage"]
    #start the run
    try:
        while True:
            if datetime.datetime.now() >= endtime: # wait until end of the run
                print("~~~End~~~")
                endofrun = True
                if keeplastimage:
                    keepimage = True
                datetimetag = numplate(scanner,folder,logfile,outputfolder) # ask for scanning
                logfileobj = open(logfile, 'a') # opens log file
                logfileobj.write(f"End trial with device {scanner} at {endtime}\nIt had started at {startime}\n") # info end of run
                logfileobj.close()
                #stop handler
                observer.stop()
                observer.join()
                open_folder(folderout) # Open the folder with the system's file explorer
                break
            datetimetag = numplate(scanner,folder,logfile,outputfolder) # ask for scanning
            time.sleep(rate*60) # sleep during rate's value converted in secondes
    except KeyboardInterrupt:
        observer.stop()
        observer.join()
