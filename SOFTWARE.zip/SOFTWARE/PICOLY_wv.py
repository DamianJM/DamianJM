"""
Minimal Color MTP MCM GUI version
Q&D GUI overCLI
Created the 2024/12/30

This file is part of MCM-Picoly.

    MCM-Picoly is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    MCM-Picoly is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with MCM-Picoly.  If not, see <https://www.gnu.org/licenses/>.



v0.1 first release
v0.2 kill specific process instead of all Python processes.
v0.3 bug fig for MTP4 plot & block start button with trick to unluck with about and menu change

@author: Nicolas Hardy : nicolas.hardy@iff.com
"""

import sys
import os
from pathlib import Path
import pickle
import datetime
import signal

import PySide2.QtWidgets as qtw
from PySide2.QtCore import Qt, QUrl
from PySide2.QtGui import QIcon
from PySide2.QtWebEngineWidgets import QWebEngineView


from MCMmain import __version__ as MCMversion

from plumbum import local,FG,BG

__version__ = 0.3



class MyWindow(qtw.QMainWindow):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)  # héritaqe d'une classe qt
        # Positional paramters
        self.timexp = 12 # Acquisition time in hours
        # Optional parameters
        self.rate = 3
        self.keepimage = False # keep image
        self.keeplastimage = False # keep last image
        # Parameters from file set as None
        self.scanner = None
        self.alpha = None
        self.beta = None
        # Set a specific working directory
        self.folder = Path(os.path.abspath(__file__)).parents[0]
        #  GUi parameters
        self.pathico = str(self.folder.joinpath("youicone.ico"))  # Création de la variable du chemin de l'icone de la fenêtre
        self.paramfile = self.folder.joinpath("MCMparam")
        self.scanfile = self.folder.joinpath("SCANparam")
        self.folderout = self.folder.joinpath(f"MCM{datetime.datetime.now().strftime('%Y%m%d')}")
        self.graphMTP1  = self.folderout.joinpath("MTP1_pH.html")
        self.graphMTP2  = self.folderout.joinpath("MTP2_pH.html")
        self.graphMTP3  = self.folderout.joinpath("MTP3_pH.html")
        self.graphMTP4  = self.folderout.joinpath("MTP4_pH.html")
        self.loadconfig()  # load config file
        self.scannerlist = []
        self.runingproc = False # place to store running process in back ground
        
        #main windows info
        self.setWindowTitle("PICOLY")
        self.setMinimumSize(360,450) #
        self.setWindowIcon(QIcon(self.pathico))  # Ajouter l'icone

        # menu bar
        menu_bar = self.menuBar()  # type: QMenuBar
        self.file_menu = menu_bar.addMenu("Menu")  # type: QMenu
        self.file_menu.addAction("Open Graph MTP1", self.showMTP1)
        self.file_menu.addAction("Open Graph MTP2", self.showMTP2)
        self.file_menu.addAction("Open Graph MTP3", self.showMTP3)
        self.file_menu.addAction("Open Graph MTP4", self.showMTP4)
        self.file_menu.addAction("Exit", qtw.QApplication.quit)
        self.file_menu2 = menu_bar.addMenu("Configuration")
        self.file_menu2.addAction("Search Scanner", self.searchscanner)
        self.file_menu2.addAction("Save Configuration", self.saveconf)
        self.file_menu3 = menu_bar.addMenu("About")
        self.file_menu3.addAction("Help", self.helpinfo)
        
        # Widget creation
        self.__casekeepall =  qtw.QCheckBox("Keep images")
        self.__casekeeplast =  qtw.QCheckBox("Keep last image")
        self.pHformuladeb = qtw.QLabel(f"(G_B) = alpha")
        self.pHformulafin = qtw.QLabel(f"*pH + beta")
        self.boutonstart = qtw.QPushButton("Start the run")  # création d'un widget button
        self.boutonstart.released.connect(self.actionclic)  # Ajout au widget button l'action actionclic cf. fonction
        self.rateinput = qtw.QSpinBox()
        self.rateinput.setValue(self.rate) # default 3 minutes
        self.rateinput.setPrefix("Frequence: ")
        self.rateinput.setSuffix(" min") # unit
        self.rateinput.setMinimum(2) # at least 2 minutes buffer time plus scanning time ~ 1 minute
        self.rateinput.setMaximum(30) # at max 30 minutes
        self.rundurinput = qtw.QSpinBox()
        self.rundurinput.setValue(self.timexp) # default 3 minutes
        self.rundurinput.setPrefix("Run time: ")
        self.rundurinput.setSuffix(" h") # unit
        self.rundurinput.setMinimum(1) # at least 1 hour
        self.textscreen = qtw.QLabel()  #Retourn d'inforamtion
        #alpha
        self.spinalpha = qtw.QDoubleSpinBox(self)
        self.spinalpha.setDecimals(6)
        self.spinalpha.setSingleStep(10**-self.spinalpha.decimals())
        self.spinalpha.setValue(-self.alpha)
        self.spinalpha.setPrefix("- ")
        #beta
        self.spinbeta = qtw.QDoubleSpinBox(self)
        self.spinbeta.setDecimals(6)
        self.spinbeta.setSingleStep(10**-self.spinalpha.decimals())
        self.spinbeta.setValue(self.beta)

        #creat droplist
        #combobox
        self.cb = qtw.QComboBox()
        self.cb.addItem(self.scanner)
        self.cb.currentIndexChanged.connect(self.scannerselection)
        self.scannertextlabel = qtw.QLabel("Scanner:")
        
        # Widget vide, c'est normal
        self.rbparent = qtw.QWidget()  # groupe de boutons
        # On créé un layout
        self.groupusb = qtw.QHBoxLayout()  #Box horizontal (QVBoxLayout pour vertical) Object contenant les Radio boutons
        self.USBgauche = qtw.QRadioButton()
        self.USBgauche.setText("Left")
        self.USBgauche.toggled.connect(self.selecteusb)
        self.USBdroit = qtw.QRadioButton()
        self.USBdroit.setText("Right")
        self.USBdroit.toggled.connect(self.selecteusb)
        self.USBlabel = qtw.QLabel(f"USB port at the:")
        #set default value
        if self.usbatright:
            self.USBdroit.toggle()
        else:
            self.USBgauche.toggle()
        #block user mistakes
        self.USBgauche.setDisabled(True)
        self.USBdroit.setDisabled(True)
        # On ajout non pas au widget mais au layout
        self.groupusb.addWidget(self.USBlabel)
        self.groupusb.addWidget(self.USBgauche)  # ajout sur le layout USBgauche
        self.groupusb.addWidget(self.USBdroit)  # ajout sur le layout USBdroit
        # On set le layout
        self.rbparent.setLayout(self.groupusb)  # Ajout du layout à un Widget vide pour faire un widget comme les autres


        #Creat a layout principale
        gridlay = qtw.QGridLayout() # creat main object
        #ligne,col,hauteur,largeur
        gridlay.addWidget(self.__casekeepall,0,0,1,2)
        gridlay.addWidget(self.__casekeeplast,0,2,1,2)
        gridlay.addWidget(self.rbparent,1,0,1,4)
        gridlay.addWidget(self.scannertextlabel,2,0,1,1)
        gridlay.addWidget(self.cb,2,1,1,3)
        gridlay.addWidget(self.rateinput,3,0,1,4)
        gridlay.addWidget(self.rundurinput,4,0,1,4)
        gridlay.addWidget(self.pHformuladeb,5,0,1,1)
        gridlay.addWidget(self.spinalpha,5,1,1,1)
        gridlay.addWidget(self.pHformulafin,5,2,1,1)
        gridlay.addWidget(self.spinbeta,5,3,1,1)
        gridlay.addWidget(self.boutonstart,6,0,1,4)
        gridlay.addWidget(self.textscreen,7,0,4,4)
        
        
        
        #creat a big vertical layout
        guiframe = qtw.QWidget()  #creation du widget central
        
        
        #set main layout
        guiframe.setLayout(gridlay)
        self.setCentralWidget(guiframe)
        
        #html viewer other window
        self.htmldisp = QWebEngineView()
        self.htmldisp.setWindowTitle("MCM-Picoly explorer")
        self.htmldisp.setMinimumSize(1000,500)   # Set minimum size
        self.htmldisp.setWindowIcon(QIcon(self.pathico))  # Ajouter l'icone

    def selecteusb(self):
        """Fonction qui map les radio boutons
        """
        if self.USBgauche.isChecked():
            self.usbatright = False
        elif self.USBdroit.isChecked():
            self.usbatright = True

    def closeEvent(self, event):
        """Make here when  close windows
        """
        print("Ask for end")
        #killbg = local["pkill"]["python"]# look on jobs
        #killbg & FG # kill all Python processes
        if self.runingproc:
            print(f"Kill process {self.runingproc.proc.pid}")
            os.kill(self.runingproc.proc.pid, signal.SIGKILL) # kill process
        
    def loadconfig(self):
        if self.paramfile.is_file():
            conf = pickle.load(open(self.paramfile, 'rb')) # read conf file
            self.scanner, self.alpha, self.beta, self.usbatright = conf # load conf
            print(conf)
        else:
            print("First create conf file with CLI MCMmain.py")
            exit()
        
    def showMTP1(self):
        self.textscreen.setText("MTP 1 plot")
        """View curves if created
        """
        self.htmldisp.load(QUrl.fromLocalFile(self.graphMTP1))
        self.htmldisp.show()

    def showMTP2(self):
        self.textscreen.setText("MTP 2 plot")
        """View curves if created
        """
        self.htmldisp.load(QUrl.fromLocalFile(self.graphMTP2))
        self.htmldisp.show()

    def showMTP3(self):
        self.textscreen.setText("MTP 3 plot")
        """View curves if created
        """
        self.htmldisp.load(QUrl.fromLocalFile(self.graphMTP3))
        self.htmldisp.show()

    def showMTP4(self):
        self.textscreen.setText("MTP 4 plot")
        """View curves if created
        """
        self.htmldisp.load(QUrl.fromLocalFile(self.graphMTP4))
        self.htmldisp.show()

    def searchscanner(self):
        """Action to search scanners
        """
        self.USBgauche.setEnabled(True)
        self.USBdroit.setEnabled(True)
        self.cb.clear()
        #here search scan on MCM$
        pythoncmd = local["python"]
        clibase = pythoncmd[f"{'MCMmain.py'}"]
        startsearch = clibase[f"{self.timexp}"]["--searchscan"]
        print(startsearch)
        startsearch & FG
        #Load output from search scan MCM
        assert self.scanfile.is_file(), "issue to create list of scanner from MCM extractqoted function on -ss/--searchscan option"
        listscan = pickle.load(open(self.scanfile, 'rb')) # read conf file
        self.scannerlist = listscan
        self.cb.addItems(self.scannerlist)
        self.textscreen.setText(f"Searching scanner")
        
    def scannerselection(self):
        """Define what happens when a new scanner is selected
        """
        self.scanner=self.cb.currentText()
        self.textscreen.setText(f"-sn {self.scanner}")

    def saveconf(self):
        """save conf as file
        """
        self.textscreen.setText("Configuration saved")
        self.alpha = -round(self.spinalpha.value(),self.spinalpha.decimals())
        self.beta = round(self.spinbeta.value(),self.spinbeta.decimals())
        print(self.usbatright)
        pythoncmd = local["python"]
        clibase = pythoncmd[f"{'MCMmain.py'}"]
        saveconfrun = clibase[f"{self.timexp}"]["-r"][f"{self.rate}"]["-sn"][f"{self.scanner}"]["-c"][f"{self.alpha}"][f"{self.beta}"]["-s"]
        if self.usbatright:
            saveconfrun=saveconfrun["-d"]
        else:
            saveconfrun=saveconfrun["-g"]
        #block user mistakes
        self.USBgauche.setDisabled(True)
        self.USBdroit.setDisabled(True)
        #print(saveconfrun)
        saveconfrun & FG

    def helpinfo(self):
        """Fonction qui imprime la version et des info dans la zone
        textscreen
        """
        MCMname= "MCM: Minimal Color of Microplate"
        PICOLYname="PICOLY: pH Indirect COLorimetrY"
        String = f"{MCMname}\n{PICOLYname}\nMCMmain v{MCMversion} & MCMGUI v{__version__}\nHelp: nicolas.hardy@iff.com\n\nCreated by: Nicolas H. (GPLv3)"
        self.textscreen.setText(String)
        # restart gui setng
        self.boutonstart.setDisabled(False) # can be restart
        self.file_menu2.clear() #clean menu
        self.file_menu2.addAction("Search Scanner", self.searchscanner)
        self.file_menu2.addAction("Save Configuration", self.saveconf)

    def actionclic(self):
        #extract value from user
        self.boutonstart.setDisabled(True) # avoid multostart
        self.file_menu2.clear() #block parameters
        self.rate = self.rateinput.value()
        self.timexp = self.rundurinput.value()
        self.alpha = -round(self.spinalpha.value(),self.spinalpha.decimals())
        self.beta = round(self.spinbeta.value(),self.spinbeta.decimals())
        if self.__casekeepall.checkState()==Qt.CheckState.Checked:
            self.keepimage = True
        else:
            self.keepimage = False
        if self.__casekeeplast.checkState()==Qt.CheckState.Checked:
            self.keeplastimage =  True
        else:
            self.keeplastimage =  False
            #Print run' setings
        inforunstr = f"\
        The run will stop after {self.timexp} hours\n\
        One point every {self.rate} minutes\
        Device used: {self.scanner}\n\
        (G_B) = {self.alpha}*pH + {self.beta}\n\
        The scanner's USB port is at {['rigth [||]--UBS--PC'if self.usbatright else 'left PC--USB--[||]']} \n\
        keepimage: {self.keepimage} \n\
        keeplastimage: {self.keeplastimage} \n\
        "
        self.textscreen.setText(inforunstr)
        pythoncmd = local["python"]
        clibase = pythoncmd[f"{'MCMmain.py'}"]
        startnum = clibase[f"{self.timexp}"]["-r"][f"{self.rate}"]["-sn"][f"{self.scanner}"]["-c"][f"{self.alpha}"][f"{self.beta}"]
        if self.keepimage:
            startnum=startnum["-k"]
        if self.keeplastimage:
            startnum=startnum["-kl"]
        if self.usbatright:
            startnum=startnum["-d"]
        else:
            startnum=startnum["-g"]
        print(startnum)
        self.runingproc = startnum & BG(stdout=sys.stdout, stderr=sys.stderr)


if __name__ == '__main__':
    os.chdir(Path(os.path.abspath(__file__)).parents[0]) # work on file directory
    application = qtw.QApplication(sys.argv)
    window = MyWindow()
    window.show()
    sys.exit(application.exec())
